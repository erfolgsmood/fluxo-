# LLM-Scoring – rechtlicher Hinweis (DE/EU)
- Das Ranking erfolgt transparent nach Kriterien Preis, Lieferzeit, Quelle.
- Keine bezahlte Bevorzugung ohne Kennzeichnung (UWG §5a). 
- Bei Affiliate-Links ist **Werbung** bzw. **Affiliate-Link** zu kennzeichnen.
