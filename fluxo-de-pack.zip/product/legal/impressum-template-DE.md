**Impressum (Muster, ausfüllen):**

Betreiber: [Name/Firma]  
Vertreten durch: [Geschäftsführer/in]  
Anschrift: [Straße, PLZ, Ort, Land]  
E-Mail: [Kontaktadresse]  
Telefon: [optional]  
USt-ID: [falls vorhanden]  
Register: [Handelsregister, Nummer, Gericht – falls vorhanden]
