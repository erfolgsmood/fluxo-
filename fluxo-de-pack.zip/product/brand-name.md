# Projektname (gewählt): **FLUXO**

Warum?
- kurz, international aussprechbar
- techy & modern, wirkt schnell/fluss (Flow → Flux)
- Domains in Varianten oft verfügbar (fluxo.de/.io/.app – final vorab prüfen)
- neutral genug für späteren Plattform-Ausbau

Falls juristischer Konflikt: Alternativen: **Athera**, **Looply**, **Zentro**.
Bitte vor Launch Marken-/Domainrecherche (DPMA & Denic) durchführen.
