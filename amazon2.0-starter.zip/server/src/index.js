import express from 'express';
import fetch from 'node-fetch';
import { rank } from './ranker.js';

const app = express();
const PORT = process.env.PORT || 4000;

app.get('/health', (req, res) => res.json({ ok: true }));

app.get('/search', async (req, res) => {
  const q = req.query.q;
  if (!q) return res.status(400).json({ error: 'q required' });

  try {
    const items = await metaSearch(q);
    const ranked = await rank(q, items);
    res.json({ query: q, items: ranked });
  } catch (e) {
    console.error(e);
    res.json({ query: q, items: [] });
  }
});

app.listen(PORT, () => console.log(`API on :${PORT}`));

async function metaSearch(q) {
  // TODO: replace with SerpAPI / partner feeds
  const demo = [
    { title: `Option A ${q}`, price: 99, currency: 'EUR', vendor: 'Demo', url: 'https://example.com/a', delivery_eta: '2–3 Tage' },
    { title: `Option B ${q}`, price: 109, currency: 'EUR', vendor: 'Demo', url: 'https://example.com/b', delivery_eta: '1–2 Tage' }
  ];
  return demo;
}
