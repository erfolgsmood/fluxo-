# 10‑Slide Pitch (Outline)

1. Problem — Online‑Kauf ist laut, intransparent, langsam
2. Lösung — Meta‑Commerce: KI sucht, vergleicht, empfiehlt
3. Produkt — Demo der Suche, Ranking, ETA
4. Warum jetzt — KI‑Sprung, Händler wollen günstige Akquise
5. Markt — E‑Commerce + B2B‑Sourcing (TAM >$1T)
6. Traction — Nutzer, CTR, Conversion, Partner
7. Moat — Daten (Klicks, Preise, ETA), Ranking‑Modelle
8. Go‑to‑Market — Nische → Kategorien → EU/US
9. Business Model — Affiliate, SaaS, Premium, B2B Reports
10. Team & Ask — Roadmap + Kapitalbedarf
