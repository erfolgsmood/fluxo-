# Landing Copy (DE)

## Headline
Finde in Sekunden das **perfekte Produkt**.

## Subheadline
Unsere KI durchsucht Shops, vergleicht Preise und Lieferzeiten und empfiehlt dir die beste Option — transparent und unabhängig.

## Call-to-Action
[Jetzt suchen]  |  Kein Login nötig

## Trust
- Keine Werbung, kein Bullshit
- Immer mit Preis/ETA/Quelle
- Bald: Preisalarm & lokale Lieferung

## Footer
Impressum · Datenschutz · Kontakt
