# Datenschutz (Minimal‑Vorlage, kein Rechtsrat)
- Wir speichern Such‑ und Klickdaten anonymisiert (IP anonymisiert).
- Cookies nur für Funktionalität.
- Externe Links führen zu Partnern (Affiliate).
- Auf Anfrage löschen wir personenbezogene Daten.
