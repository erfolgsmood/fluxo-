# Impressum (Placeholder)
Betreiber: [Dein Name/Firma]  
Adresse: [Straße, PLZ, Stadt, Land]  
E‑Mail: [Kontakt]  
USt‑ID: [falls vorhanden]
