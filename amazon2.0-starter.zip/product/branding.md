# Branding

**Name (Shortlist):** Fluxo, Looply, Athera, Nexar  
**Claim:** „KI findet das perfekte Produkt.“  
**Werte:** Schnell, ehrlich, hilfreich.  
**Tone of Voice:** Klar, technisch, pro‑Kunde.

Farben/Look: minimal, weiß/hell, viel Whitespace, klare Typo.
